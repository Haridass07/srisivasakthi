document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("menuForm");
  const totalAmountEl = document.getElementById("totalAmount");

  if (form) {
    form.addEventListener("input", () => {
      let total = 0;
      const inputs = form.querySelectorAll("input[type='number']");
      inputs.forEach(input => {
        const qty = parseInt(input.value) || 0;
        const price = parseInt(input.dataset.price);
        total += qty * price;
      });
      totalAmountEl.textContent = total;
    });
  }
});
