const dispatchApi = require("./api/dispatch");
const secretManager = require("./Helper/Common/secretHelper");
const dotenv = require("dotenv");
const logger = require("./Helper/Utilities/logger");

exports.handler = async (event, context) => {
    let body = {};
    try {
        body = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    } catch (err) {
        console.log("Invalid JSON in event.body");
        return {
            statusCode: 400,
            body: JSON.stringify({ error: "Invalid request body" }),
        };
    }

    // --- Dynamic environment & log level per request ---
    const appEnv = body?.SapEnvironment || "prod";
    const logLevel = body?.logLevel || "info";
    const conId = body?.ConversationId || "";
    const awsRequestId = context.awsRequestId;

    // Store in process.env only what’s safe for reuse
    process.env.appEnv = appEnv;
    process.env.logLevel = logLevel;
    process.env.conId = conId;
    process.env.awsRequestId = awsRequestId;
    // --- Get secrets ---
    try {
        const secret = await secretManager.getSecretValue(process.env.secretName);
        if (!secret) {
            logger.error("Secrets not found, aborting request");
            return {
                statusCode: 500,
                body: JSON.stringify({ error: "Internal configuration error" }),
            };
        }

        // Assign secrets for downstream use
        process.env.publicKey = secret.publicKey;
        process.env.apiKey = secret.apiKey;
        process.env.apiValue = secret.apiValue;
        process.env.AccessToken = secret.accessToken;
        process.env.accessTokenGeneratedTimestamp =
        secret.accessTokenGeneratedTimestamp;
        process.env.vdevXAPIKey = secret["X-API-KEY"];
        process.env.apigateUsername = secret.apigateUsername;
        process.env.apigatePassword = secret.apigatePassword;

        console.log("Successfully retrieved secret manager values");
    } catch (err) {
        console.log(`Secret Manager fetch failed: ${err.message}`);
        return {
            statusCode: 500,
            body: JSON.stringify({ error: "Secret Manager error" }),
        };
    }

    logger.info("Lambda handler started");
    logger.debug({ body });
    logger.info(`App Environment: ${appEnv}`);
    logger.info(`Log Level: ${logLevel}`);
    const envConfig = dotenv.config({ path: `./Helper/Config/.${appEnv}` });
    if (!envConfig.error) {
        Object.assign(process.env, envConfig.parsed);
    } else {
        logger.warn(`No env config found for env: ${appEnv}`);
    }

    // --- Default response template ---
    let response = {
        statusCode: 200,
        headers: {
            "Content-Type": "application/json",
            "Access-Control-Allow-Headers":
                "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
            "Access-Control-Allow-Methods": "*",
            "Access-Control-Allow-Origin": "*",
        },
        body: JSON.stringify({}),
    };

    // --- Route handling ---
    if (!event.routeKey) {
        event.routeKey = `${event.httpMethod} ${event.resource}`;
    }

    if (event.httpMethod === "OPTIONS") {
        logger.info("OPTIONS request received. Returning default response.");
        return response;
    }

    logger.info("Dispatching request to handler");
    try {
        response = await dispatch(event, response, awsRequestId, conId);
    } catch (err) {
        logger.error(`Dispatch failed: ${err.message}`);
        response.statusCode = 500;
        response.body = JSON.stringify({ error: err.message });
    }
    logger.info("Lambda handler completed");

    return response;
};

// --- Basic Auth parser ---
function parseBasicAuth(authHeader) {
    if (!authHeader || !authHeader.startsWith("Basic ")) return null;
    const base64Credentials = authHeader.split(" ")[1];
    const decoded = Buffer.from(base64Credentials, "base64").toString("utf-8");
    const [username, password] = decoded.split(":");
    return { username, password };
}

// --- Dispatcher ---
const dispatch = async (event, response, awsRequestId, conId) => {
    logger.info({ message: "Inside dispatch function", awsRequestId, conId });

    try {
        const authHeader = event.headers?.Authorization;
        const creds = parseBasicAuth(authHeader);
        const expectedUser = process.env.apigateUsername;
        const expectedPass = process.env.apigatePassword;

        if (creds && creds.username === expectedUser && creds.password === expectedPass) {
            logger.info("Authorization successful");
            response = await dispatchApi.handler(event, response);
            logger.info("Dispatch handler completed");
        } else {
            logger.error("Unauthorized request");
            response.statusCode = 401;
            response.body = JSON.stringify({
                Result: false,
                status: 401,
                errorMessage: "Unauthorized",
            });
        }
    } catch (err) {
        logger.error(`Dispatch Error: ${err.message}`);
        logger.debug(`Stack Trace: ${err.stack}`);
        response.statusCode = 500;
        response.body = JSON.stringify({
            Result: false,
            status: 500,
            errorMessage: err.message,
        });
    }

    return response;
};
