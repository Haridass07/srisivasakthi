const { PointelLogger } = require("pointel-logger/pointelLogger");

const sensitiveFields = [
  "$..publicKey",
  "$..apiKey",
  "$..apiValue",
  "$..content",
  "$..contentType",
  "$.url",
  "$..getSensitefields",
];

let loggerInstance = null;

/**
 * Initialize or return existing logger
 */
function getInstance() {
  if (!loggerInstance) {
    if (!process.env.publicKey) {
      console.warn("[WARN] PointelLogger initialized without publicKey");
    }
    loggerInstance = new PointelLogger(
      process.env.publicKey || "",
      process.env.conId || "",
      process.env.awsRequestId || "",
      process.env.logLevel || "info",
      sensitiveFields
    );
  }
  return loggerInstance;
}

/**
 * Reset logger instance
 */
function clear() {
  loggerInstance = null;
}

/**
 * Safe wrapper around log calls
 */
function log(level, message) {
  try {
    getInstance().log(level, message);
  } catch (err) {
    console.error(`[LOGGER ERROR] Failed to log at level ${level}: ${err.message}`);
  }
}

function info(msg) {
  log("info", msg);
}

function debug(msg) {
  log("debug", msg);
}

function warn(msg) {
  log("warn", msg);
}

function error(msg) {
  log("error", msg);
}

function lexCallback(response, originalCallback) {
  try {
    debug(response);
    if (typeof originalCallback === "function") {
      originalCallback(null, response);
    }
  } catch (err) {
    console.error("[LOGGER ERROR] lexCallback failed:", err.message);
  }
}

module.exports = {
  info,
  debug,
  warn,
  error,
  lexCallback,
  getInstance,
  clear,
};
