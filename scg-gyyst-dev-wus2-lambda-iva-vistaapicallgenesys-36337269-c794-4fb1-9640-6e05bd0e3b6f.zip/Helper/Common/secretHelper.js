const AWS = require("aws-sdk");
const secretsManager = new AWS.SecretsManager();
const logger = require("../Utilities/logger"); // adjust path

let secretCache = {}; // support caching multiple secrets

// --------------------- fetchSecret --------------------- //
const fetchSecret = async () => {
  const fetchSecretName = process.env.secretName;

  if (!fetchSecretName) {
    logger.warn("fetchSecret - process.env.secretName is undefined.");
    return null;
  }

  try {
    const data = await secretsManager.getSecretValue({ SecretId: fetchSecretName }).promise();

    let secret;
    if ("SecretString" in data) {
      secret = data.SecretString;
    } else {
      secret = Buffer.from(data.SecretBinary, "base64").toString("ascii");
    }

    try {
      return JSON.parse(secret);
    } catch {
      return secret; // return as string if not JSON
    }
  } catch (err) {
    logger.error(`fetchSecret - Failed to retrieve secret "${fetchSecretName}": ${err.message}`);
    return null;
  }
};

// --------------------- getSecretValue --------------------- //
const getSecretValue = async (secretName) => {
  if (!secretName) {
    logger.warn("getSecretValue - Secret name is undefined or empty.");
    return null;
  }

  // Return cached secret if available
  if (secretCache[secretName]) {
    return secretCache[secretName];
  }

  try {
    const data = await secretsManager.getSecretValue({ SecretId: secretName }).promise();

    if (data && data.SecretString) {
      const parsedSecret = JSON.parse(data.SecretString);
      secretCache[secretName] = parsedSecret; // cache it
      return parsedSecret;
    } else {
      logger.info(`getSecretValue - Secret "${secretName}" found but missing SecretString.`);
      return null;
    }
  } catch (err) {
    logger.error(`getSecretValue - Failed to retrieve secret "${secretName}": ${err.message}`);
    return null;
  }
};

module.exports = {
  getSecretValue,
  fetchSecret
};
