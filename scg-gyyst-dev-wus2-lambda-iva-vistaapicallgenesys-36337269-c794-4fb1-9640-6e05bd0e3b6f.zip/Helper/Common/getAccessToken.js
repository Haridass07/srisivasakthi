const logger = require("../Utilities/logger"); // adjust path as needed

function isTokenExpired(accessTokenGeneratedTimestamp) {
    const tokenTime = new Date(accessTokenGeneratedTimestamp).getTime(); // when token was generated
    const now = Date.now(); // current UTC time in ms
    const elapsedMinutes = (now - tokenTime) / (1000 * 60); // convert ms to minutes
    logger.debug(`Elapsed minutes since token generation: ${elapsedMinutes}`);
    return elapsedMinutes > 55;
}

module.exports = { isTokenExpired };
