const fs = require("fs");
const path = require("path");
const axios = require("axios");
const { isTokenExpired } = require("../Common/getAccessToken");
const { fetchSecret } = require("../Common/secretHelper");
const { DateTime } = require("luxon");
const logger = require("../Utilities/logger"); // <- added logger

const timezone = "America/Los_Angeles";

// -------------------- Build Request Object -------------------- //
const getRequestObject = async function (AU_WS_ID, reqObj) {
  try {
    // Ensure access token is fresh
    let tokenGeneratedTimestamp = process.env.accessTokenGeneratedTimestamp;
    const tokenExpired = await isTokenExpired(tokenGeneratedTimestamp);

    if (tokenExpired) {
      logger.info("Access token expired. Fetching new token...");
      const secret = await fetchSecret();
      if (!secret) {
        logger.error("Failed to retrieve secret manager values");
      } else {
        process.env.AccessToken = secret.accessToken;
        process.env.accessTokenGeneratedTimestamp = secret.accessTokenGeneratedTimestamp;
      }
    } else {
      logger.info("Access token still valid");
    }

    // Load template JSON
    const reqParamsPath = path.join(__dirname, "../Config/apiReqResp.json");
    if (!fs.existsSync(reqParamsPath)) {
      throw new Error(`Template JSON file not found: ${reqParamsPath}`);
    }

    const allTemplates = JSON.parse(fs.readFileSync(reqParamsPath, "utf8"));
    const template = allTemplates[AU_WS_ID];
    if (!template) {
      throw new Error(`No template found for WS_ID: ${AU_WS_ID}`);
    }

    // Build body from template + request input
    let body = { ...template.body };
    const dt = DateTime.now().setZone(timezone);

    const timeStamp = dt.toISO();                 // full ISO if needed
    const RequestedOn = dt.toFormat("MMddyyyy");  // e.g., "09242025"
    const RequestedTime = dt.toFormat("HHmmss");  // e.g., "231512"

    logger.debug(`Full ISO: ${timeStamp}`);
    logger.debug(`RequestedOn: ${RequestedOn}`);
    logger.debug(`RequestedTime: ${RequestedTime}`);

    switch (AU_WS_ID) {
      case "I_DG_06_006":
        body.PhoneNumber = reqObj.phoneNumber;
        body.ContractAccount = reqObj.contractAccount;
        body.CheckDigit = reqObj.checkDigit;
        body.RequestedBy = reqObj.requestedBy;
        body.RequestedTimeStamp = timeStamp;
        break;
      case "I_DG_01_008":
        body.RequestedBy = reqObj.RequestedBy;
        body.RequestedTime = RequestedTime;
        body.RequestedOn = RequestedOn;
        body.ZGCreateContactLogItem[0].PrimaryBusinessPartner = reqObj.PrimaryBusinessPartner;
        body.ZGCreateContactLogItem[0].ContactCompanyCode = reqObj.ContactCompanyCode;
        body.ZGCreateContactLogItem[0].ContractAccount = reqObj.ContractAccount;
        body.ZGCreateContactLogItem[0].ContactClass = reqObj.ContactClass;
        body.ZGCreateContactLogItem[0].ContactAction = reqObj.ContactAction;
        body.ZGCreateContactLogItem[0].ContactChannelType = reqObj.ContactChannelType;
        body.ZGCreateContactLogItem[0].ContactInOutGoing = reqObj.ContactInOutGoing;
        body.ZGCreateContactLogItem[0].ContactLanguage = reqObj.ContactLanguage;
        body.ZGCreateContactLogItem[0].ContactNotes = reqObj.ContactNotes;
        break;
      case "I_DG_03_006":
        body.ZGOtpGetPayCA[0].ContractAccount = reqObj.ContractAccount;
        body.RequestedBy = reqObj.requestedBy;
        body.RequestedTimeStamp = timeStamp;
        break;
    }

    // Prepare Axios config
    const headers = {
      "Content-Type": "application/json",
      Accept: "*/*",
      "x-api-key": process.env.vdevXAPIKey,
      Authorization: `Bearer ${process.env.AccessToken}`
    };

    const axiosConfig = {
      method: template.method || "POST",
      url: process.env[AU_WS_ID], // dynamic URL from env
      headers,
      timeout: template.timeout || 10000,
      data: template.method === "POST" ? body : undefined,
      params: template.method === "GET" ? body : undefined
    };

    return axiosConfig;
  } catch (error) {
    logger.error(`Failed to build request object: ${error.message}`);
    throw error;
  }
};

// -------------------- Execute Request -------------------- //
const getResponseObject = async function (axiosConfig) {
  try {
    logger.debug("===== AXIOS CONFIG =====");
    logger.debug(JSON.stringify(axiosConfig, null, 2));
    logger.debug("========================");
    logger.debug(`API REQUEST URL: ${axiosConfig.url}`);
    logger.debug(`API REQUEST Method: ${axiosConfig.method}`);
    logger.debug(`API REQUEST Headers: ${JSON.stringify(axiosConfig.headers)}`);
    if (axiosConfig.data) logger.debug(`API REQUEST Body: ${JSON.stringify(axiosConfig.data)}`);

    const response = await axios(axiosConfig);

    logger.info("API call complete");
    logger.debug(`Status: ${response.status}`);

    let responseData = response.data;

    // Handle SAP-style wrapper `{ d: { ... } }`
    if (responseData && responseData.d) {
      responseData = responseData.d;
    }

    return {
      status: response.status,
      data: responseData
    };
  } catch (error) {
    const isTimeout =
      error.code === "ECONNABORTED" ||
      error.code === "ESOCKETTIMEDOUT" ||
      error.code === "ETIMEDOUT";

    if (isTimeout) {
      logger.error(`API request timed out: ${error.code}`);
    }

    logger.error(`API call failed: ${error.message}`);

    return {
      status: error.response?.status || 500,
      error: true,
      message: error.message,
      data: error.response?.data || null
    };
  }
};

module.exports = {
  getRequestObject,
  getResponseObject
};
