const apiHelper = require("../../Helper/Common/apiHelper");
const logger = require("../../Helper/Utilities/logger");

exports.handler = async (event) => {
  logger.info("createContactLog handler started");

  let response = {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*"
    },
    body: ""
  };

  try {
    // Parse request body safely
    const req = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    logger.info(`Incoming Request Payload: ${JSON.stringify(req)}`);

    // Prepare request object
    const createContactLog = {};
    createContactLog.RequestedBy = req.RequestedBy;
    createContactLog.PrimaryBusinessPartner = req.PrimaryBusinessPartner;
    createContactLog.ContactCompanyCode = req.ContactCompanyCode;
    createContactLog.ContractAccount = req.ContractAccount;
    createContactLog.ContactClass = req.ContactClass;
    createContactLog.ContactAction = req.ContactAction;
    createContactLog.ContactChannelType = req.ContactChannelType;
    createContactLog.ContactInOutGoing = req.ContactInOutGoing;
    createContactLog.ContactLanguage = req.ContactLanguage;
    createContactLog.ContactNotes = req.ContactNotes;

    logger.info(`createContactLog object prepared: ${JSON.stringify(createContactLog)}`);

    // Build request for external API
    const createContactLogReqObj = await apiHelper.getRequestObject("I_DG_01_008", createContactLog);
    logger.info("Request prepared for createContactLog");

    // Call external API
    const createContactLogResObj = await apiHelper.getResponseObject(createContactLogReqObj);
    logger.info("Response received from createContactLog");

    if (!createContactLogResObj) {
      throw new Error("createContactLog not found in response");
    }

    response.statusCode = 200;
    response.body = JSON.stringify(createContactLogResObj, null, 2);
    logger.info("createContactLog response successfully prepared");

  } catch (err) {
    logger.error(`Error in createContactLog handler: ${err.message}`);
    logger.debug(`Stack Trace: ${err.stack}`);

    response.statusCode = 500;
    response.body = JSON.stringify({
      result: false,
      status: 500,
      errorMessage: err.message || "Internal Server Error"
    });
  }

  return response;
};
