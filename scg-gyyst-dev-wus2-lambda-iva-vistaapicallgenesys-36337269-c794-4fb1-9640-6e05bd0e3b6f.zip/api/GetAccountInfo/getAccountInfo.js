const apiHelper = require("../../Helper/Common/apiHelper");
const logger = require("../../Helper/Utilities/logger");

exports.handler = async (event) => {
  logger.info("ScreenPop handler started");

  let response = {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*"
    },
    body: ""
  };

  try {
    // Parse request body safely
    const req = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    logger.info(`Incoming Request Payload: ${JSON.stringify(req)}`);

    // Prepare request object
    const getAccountInfo = {
      requestedBy: req.RequestedBy,
      contractAccount: req.ContractAccount,
      phoneNumber: req.PhoneNumber,
      checkDigit: req.CheckDigit
    };

    logger.info(`getAccountInfo object prepared: ${JSON.stringify(getAccountInfo)}`);

    // Build request for external API
    const getAccountInfoReqObj = await apiHelper.getRequestObject("I_DG_06_006", getAccountInfo);
    logger.info("Request prepared for getAccountInfo");

    // Call external API
    const getAccountInfoResObj = await apiHelper.getResponseObject(getAccountInfoReqObj);
    logger.info("Response received from getAccountInfo");

    if (!getAccountInfoResObj) {
      throw new Error("AccountInfo not found in response");
    }

    response.statusCode = 200;
    response.body = JSON.stringify(getAccountInfoResObj, null, 2);
    logger.info("getAccountInfo response successfully prepared");

  } catch (err) {
    logger.error(`Error in getAccountInfo handler: ${err.message}`);
    logger.debug(`Stack Trace: ${err.stack}`);

    response.statusCode = 500;
    response.body = JSON.stringify({
      result: false,
      status: 500,
      errorMessage: err.message || "Internal Server Error"
    });
  }

  return response;
};
