const logger = require("../Helper/Utilities/logger");

exports.handler = async (event) => {
    logger.info("Dispatch handler started");
    logger.debug(`Incoming Event: ${JSON.stringify(event)}`);

    let api;

    try {
        switch (event.routeKey) {
            case "POST /getaccountinfo":
                logger.info("Route matched: POST /getaccountinfo");
                api = require("../api/GetAccountInfo/getAccountInfo");
                break;
            case "POST /createcontactlog":
                logger.info("Route matched: POST /createcontactlog");
                api = require("../api/CreateContactLog/createContactLog");
                break;
            case "POST /onetimepayment":
                logger.info("Route matched: POST /onetimepayment");
                api = require("../api/OneTimePayment/oneTimePayment");
                break;

            default:
                logger.error(`Unsupported route: ${event.routeKey}`);
                return {
                    statusCode: 404,
                    headers: {
                        "Content-Type": "application/json",
                        "Access-Control-Allow-Origin": "*"
                    },
                    body: JSON.stringify({
                        error: "Not Found",
                        message: `Unsupported route: "${event.routeKey}"`
                    })
                };
        }

        logger.info(`Dispatching to handler: ${event.routeKey}`);
        const result = await api.handler(event);
        logger.info("Route handler completed successfully");

        return {
            statusCode: result.statusCode || 200,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: typeof result.body === "string" ? result.body : JSON.stringify(result.body)
        };

    } catch (error) {
        logger.error(`Handler exception: ${error.message}`);
        logger.debug(`Stack trace: ${error.stack}`);

        return {
            statusCode: 500,
            headers: {
                "Content-Type": "application/json",
                "Access-Control-Allow-Origin": "*"
            },
            body: JSON.stringify({
                error: "Internal Server Error",
                message: error.message || "Unexpected error occurred"
            })
        };
    }
};
