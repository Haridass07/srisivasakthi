const apiHelper = require("../../Helper/Common/apiHelper");
const logger = require("../../Helper/Utilities/logger");

exports.handler = async (event) => {
  logger.info("OneTimePayment handler started");

  let response = {
    statusCode: 200,
    headers: {
      "Content-Type": "application/json",
      "Access-Control-Allow-Origin": "*"
    },
    body: ""
  };

  try {
    // Parse request body safely
    const req = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
    logger.info(`Incoming Request Payload: ${JSON.stringify(req)}`);

    // Prepare request object
    const oneTimePayment = {
      contractAccount: req.ContractAccount
    };

    logger.info(`oneTimePayment object prepared: ${JSON.stringify(oneTimePayment)}`);

    // Build request for external API
    const oneTimePaymentReqObj = await apiHelper.getRequestObject("I_DG_06_006", oneTimePayment);
    logger.info("Request prepared for oneTimePayment");

    // Call external API
    const oneTimePaymentResObj = await apiHelper.getResponseObject(oneTimePaymentReqObj);
    logger.info("Response received from oneTimePayment");

    if (!oneTimePaymentResObj) {
      throw new Error("oneTimePayment not found in response");
    }

    response.statusCode = 200;
    response.body = JSON.stringify(oneTimePaymentResObj, null, 2);
    logger.info("oneTimePayment response successfully prepared");

  } catch (err) {
    logger.error(`Error in oneTimePayment handler: ${err.message}`);
    logger.debug(`Stack Trace: ${err.stack}`);

    response.statusCode = 500;
    response.body = JSON.stringify({
      result: false,
      status: 500,
      errorMessage: err.message || "Internal Server Error"
    });
  }

  return response;
};
