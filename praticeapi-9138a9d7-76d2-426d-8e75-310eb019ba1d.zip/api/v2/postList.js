exports.handler = async(event, response) => {
    try {
        console.log("service Now  API");
        var userService = new require("../../service/v2/postList")();
        var request = JSON.parse(event.body);
        
        var result = await userService.getTicketDetails(request.teamid);
         if (JSON.stringify(result) != JSON.stringify({})) {
             
             if(result.teamid===request.teamid)
             {
                 console.log("if===exits alredy");
                  response.statusCode = 200;
                 response.body = {
                "result": "already exits"
            
                 };
                 }else
            {
                 var ticket = await userService.addOrUpdateTicket(request);
             if (JSON.stringify(ticket) != JSON.stringify({})) {
               response.statusCode = 200;
                response.body = {
                "result":"file object created",
                "status": 200
            };
        }
                
            };
             }
            else {
                var ticket = await userService.addOrUpdateTicket(request);
             if (JSON.stringify(ticket) != JSON.stringify({})) {
               response.statusCode = 200;
                response.body = {
                "result":"file object created",
                "status": 200
            };
        }
        };
        
     
    } catch (err) {
        response.statusCode = 500;
        response.body = {
            "result": false,
            "status": 500,
            "errorMessage": err.message
        };
    }
    return response;
};