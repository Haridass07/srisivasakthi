
exports.handler = async(event, response) => {
    try {
        console.log("team list lookup API: handler");
        var userService = new require("../../service/v2/deleteList")();
        var request = JSON.parse(event.body);
        console.log("teamid--->"+request.teamid)
        var result = await userService.getTicketDetail(request.teamid);
        console.log("result from service v2 delete request object"+ JSON.stringify(result));
        if (JSON.stringify(result) != JSON.stringify({})) 
        {
           if(result.teamid===request.teamid)
           {
            var result = await userService.getTicketDetails(result);
           console.log(result);
            response.statusCode = 200;
            response.body = {
                "result":"list oject deleted",
                "status": 200
            };
          }else{
               
             response.statusCode = 200;
            response.body = {
                "status": "No Data found youcannot delete!!!!"
            };
           };
        }else{
               
             response.statusCode = 200;
            response.body = {
                "result": false,
              "status": 500,
              "errorMessage": "Invalid Details!"
            };
           };
    } catch (err) {
        response.statusCode = 500;
        response.body = {
            "result": false,
            "status": 500,
            "errorMessage": err.message
        };
    }
    return response;
};