exports.handler = async(event, response) => {
    try {
        console.log("service Now  API");
        var userService = new require("../../service/v2/ticket")();
        var request = JSON.parse(event.body);
        var ticket = await userService.putTicket(request.teamid);
        console.log("Response from sevice v2 putTicket---->"+ticket);
        if (JSON.stringify(ticket) != JSON.stringify({})) {
            ticket.teamid = request.teamid;
            ticket.TeamLead =  request.TeamLead;
            ticket.team_member1 = request.team_member1;
            ticket.team_member2 = request.team_member2;
            ticket.team_member3 = request.team_member3;
            ticket.team_member4 = request.team_member4;
            ticket.team_member5 = request.team_member5;
            ticket.team_member6 = request.team_member6;
            await userService.addOrUpdateTicket(ticket);
            response.statusCode = 200;
            response.body = {
                "result":"updated successfully",
                "status": 200
            };
        } else {
            response.statusCode = 404;
            response.body = {
                "result": false,
                "status": 404,
                "ticketNum": "000000013281442",
                "errorMessage": "Failed authentication!"
            };
        }
    } catch (err) {
        response.statusCode = 500;
        response.body = {
            "result": false,
            "status": 500,
            "errorMessage": err.message
        };
    }
    return response;
};