exports.handler = async(event, response) => {
    try {
        console.log("RSA AUthentication Api  API");
         var policynum=event.pathParameters.contractnumber;
        var passwordService = new require("../../service/v2/policynew")();
        var request = JSON.parse(event.body);
       console.log("request"+request);
       console.log("request.Contract_number"+policynum);
        var customer = await passwordService.getServiceNowResponse(policynum);
        console.log(customer);
        if (JSON.stringify(customer) != JSON.stringify({})) {
            
            console.log(customer);
            response.statusCode = 200;
           response.body =customer.response;
       
    } else {

        response.statusCode = 500;
        response.body = {
            "result": false,
            "status": 500,
            "errorMessage": "Policy Failed!"
        };
    }
    } catch (err) {
        response.statusCode = 500;
        response.body = {
            "result": false,
            "status": 500,
            "errorMessage": err.message
        };
    }
    return response;
};