
exports.handler = async(event, response) => {
    try {
        console.log("team list lookup API: handler");
        var userService = new require("../../service/v2/teamList")();
        var teamid = event.queryStringParameters.teamid;
        console.log("teamid--->"+event.queryStringParameters.teamid)
        var result = await userService.getTicketDetails(teamid);
         console.log("Response form sevice v2--->"+result);
        console.log("result");
        console.log(result);
        if (JSON.stringify(result) != JSON.stringify({})) 
        {
            console.log(result);
            response.statusCode = 200;
            response.body = result.response;
            return response;
           
        }
         else {
            response.statusCode = 500;
            response.body = {
                "result": false,
                "status": 500,
                "errorMessage": "Invalid Details!"
            };
        }
    } catch (err) {
        response.statusCode = 500;
        response.body = {
            "result": false,
            "status": 500,
            "errorMessage": err.message
        };
    }
    return response;
};