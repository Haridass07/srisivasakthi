exports.handler = async(event, response) => {
    try {
        console.log("RSA AUthentication Api  API");
        var passwordService = new require("../../service/v2/customersearch")();
        //console.log(event.body.Contract_number);
        var request = JSON.parse(event.body);
       console.log("request"+request);
       console.log("request value--->"+request.policyNumber);
        var customer = await passwordService.getUserById(request.policyNumber);
        console.log("response from sevice v2--->"+customer);
        if (JSON.stringify(customer) != JSON.stringify({})) {
            
            console.log(customer);
            response.statusCode = 200;
              response.body =customer.response;
           
        
        } else {

            response.statusCode = 500;
            response.body = {
                "result": false,
                "status": 500,
                "errorMessage": "Failed authentication!"
            };
        }
    } catch (err) {
        response.statusCode = 500;
        response.body = {
            "result": false,
            "status": 500,
            "errorMessage": err.message
        };
    }
    return response;
};