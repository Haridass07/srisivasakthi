exports.handler = async(event, response) => {
    try {
        console.log("calling api v2-PartyID ");
        var passwordService = new require("../../service/v2/partyid")();
         var request = JSON.parse(event.body);
        console.log("pass json--->"+request);
        var customer = await passwordService.getUserById(request.partyID);
        console.log("Response from seviceapi-v2--->"+customer);
        if (JSON.stringify(customer) != JSON.stringify({})) {
            console.log(" seviceapi-v2- json check--->"+customer);
            if (customer.partyID === request.partyID) {

                response.statusCode = 200;
                response.body = {
                   "status": 200
                };
            } else {
                response.statusCode = 500;
                response.body = {
                    "result": false,
                    "status": 500,
                   "errorMessage": "Failed authentication - No PartyID Found"
                };
            }
        } else {

            response.statusCode = 500;
            response.body = {
                "result": false,
                "status": 500,
                "errorMessage": "Failed authentication!"
            };
        }
    } catch (err) {
        response.statusCode = 500;
        response.body = {
            "result": false,
            "status": 500,
            "errorMessage": err.message
        };
    }
    return response;
};