exports.handler = async(event, response) => {
    var api = undefined;
    console.log("event.routeKey-->"+event.routeKey);
    switch (event.routeKey) {             
        case "POST /partyid":
            console.log("called"+event.routeKey);
            api = new require("../api/v2/authenticationNew");
            break;
        case "GET /policies/{contractnumber}":
            console.log("called"+event.routeKey);
            api = new require("../api/v2/PolicyNew");
            break;
        case "POST /customers/search":
            console.log("called"+event.routeKey);
            api = new require("../api/v2/customersearch");
            break;
        case "PUT /servicecatalog":
            console.log("called"+event.routeKey);
            api = new require("../api/v2/ticket");
            break;
        case "GET /teamlist":
            console.log("called"+event.routeKey);
                api = new require("../api/v2/teamList");
                break;
        case "POST /listupdate":
            console.log("called"+event.routeKey);
                api = new require("../api/v2/postList");
                break; 
        case "DELETE /teamlistdelete":
            console.log("called"+event.routeKey);
                api = new require("../api/v2/deleteList");
                break;
        default:
            throw new Error(`Unsupported route: "${event.routeKey}"`);
    }
    return await api.handler(event, response);
};