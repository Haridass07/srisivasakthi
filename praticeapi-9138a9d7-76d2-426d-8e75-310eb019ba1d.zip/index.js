const dispatchApi = require("./api/dispatch");

exports.handler = async(event, context) => {
    console.log("Incoming Event Details:", event);
    console.log("Context:", context);
    let response = {
        body: {},
        statusCode: 200,
        headers: {
            "Content-Type": "application/json,application/xml",
            "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
            "Access-Control-Allow-Methods": "*",
            "Access-Control-Allow-Origin": "*"
        }
    };
    if (typeof event.routeKey === "undefined")
        event.routeKey = event.httpMethod + " " + event.resource;
    if (event.httpMethod == "OPTIONS")
        return response;
    else
        return await dispatch(event, response);
};

let dispatch = async(event, response) => {
    try {
        console.log("Route:", event.routeKey);
        //response = await loginApi.authenticate(event, response);
         response.statusCode === 500;
     //   if(event.headers.Authorization ==="Basic SGFyaTpIYXJpQDE5OTk=")
     //   {
        console.log("calling:auth");
        response.statusCode === 200;
        
        if (response.statusCode == 200){
             console.log("calling:dispatchApi");
            response = await dispatchApi.handler(event, response);
        }
    //    }
        
    } catch (err) {
        response.statusCode = 500;
        response.body = {
            "Result": false,
            "status": 500,
            "errorMessage": err.message
        };
    } finally {
            console.log("calling:index finally");
        response.body = JSON.stringify(response.body);
    }
    console.log("Response:", response);
    return response;
};