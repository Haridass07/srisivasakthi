module.exports = function() {
    this.jsonDb = new require("../../data/jsonDbFactory")("PolicyNew", "Items");

   this.getServiceNowResponse = async function(Contract_number) {
        console.log("Contract_number-->"+Contract_number);
        return await this.jsonDb.find({ Contract_number: Contract_number }, ["response"]);
    };
    return this;
}