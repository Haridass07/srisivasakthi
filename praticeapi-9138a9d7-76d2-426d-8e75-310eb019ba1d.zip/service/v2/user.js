module.exports = function() {
    this.jsonDb = new require("../../data/jsonDbFactory")("Authentication", "Items");

    this.getUserById = async function(Contract_number) {
        var displayFields = ["Contract_number","ANI","policy","ProductGroup","partyID"];
        return await this.jsonDb.find({ Contract_number: Contract_number }, displayFields);
    };
    return this;
}