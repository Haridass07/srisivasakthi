module.exports = function() {
    this.jsonDb = new require("../../data/jsonDbFactory")("teamID", "Items");
    this.addOrUpdateTicket = async function(request) {
        await this.jsonDb.add( request);
    };
     this.getTicketDetails = async function(teamid) {
        console.log("called  getTicketDetails service ")
        return await this.jsonDb.find({teamid: teamid }, ["teamid","response"]);
    };
    return this;
}