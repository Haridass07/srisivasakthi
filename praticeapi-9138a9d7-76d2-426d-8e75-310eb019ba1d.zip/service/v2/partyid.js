module.exports = function() {
    console.log("calling sevice v2-api");
    this.jsonDb = new require("../../data/jsonDbFactory")("PartyID", "Items");

    this.getUserById = async function(partyID) {
        var displayFields = ["partyID"];
        console.log("display field values--->"+displayFields);
        return await this.jsonDb.find({ partyID: partyID }, displayFields);
    };
    return this;
}