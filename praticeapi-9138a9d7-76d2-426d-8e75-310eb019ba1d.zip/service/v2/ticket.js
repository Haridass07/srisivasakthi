module.exports = function() {
    this.jsonDb = new require("../../data/jsonDbFactory")("teamID", "Items");
    this.addOrUpdateTicket = async function(ticket) {
        await this.jsonDb.update({ teamid: ticket.teamid }, ticket);
    };
    this.putTicket = async function(teamid) {
        var displayFields = ["teamid","response"];
        return await this.jsonDb.find({ teamid: teamid }, displayFields);
    };
    return this;
}