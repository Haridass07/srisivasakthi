module.exports = function() {
   this.jsonDb = new require("../../data/jsonDbFactory")("teamID", "Items");
    this.getTicketDetails = async function(teamid) {
        console.log("called service ")
        return await this.jsonDb.find({teamid: teamid }, ["response"]);
    };
    return this;
}
