module.exports = function() {
   this.jsonDb = new require("../../data/jsonDbFactory")("teamID", "Items");
    this.getTicketDetails = async function(result) {
        console.log("called service ")
        return await this.jsonDb.delete(result);
    };
     this.getTicketDetail = async function(teamid) {
        console.log("called  getTicketDetails service ")
        return await this.jsonDb.find({teamid: teamid }, ["teamid","response"]);
    };
    return this;
}
