module.exports = function() {
    this.jsonDb = new require("../../data/jsonDbFactory")("CustomerSearch", "Items");

    this.getUserById = async function(Contract_number) {
        var displayFields = ["Contract_number","localAreaCode","localPhoneNumber","response"];
        return await this.jsonDb.find({ Contract_number: Contract_number }, displayFields);
    };
    return this;
}