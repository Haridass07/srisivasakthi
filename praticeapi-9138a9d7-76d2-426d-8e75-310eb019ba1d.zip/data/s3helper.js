const AWS = require("aws-sdk");
// var credentials = new AWS.SharedIniFileCredentials({ profile: 'work' });
// AWS.config.credentials = credentials;
var s3 = new AWS.S3();

module.exports = function() {
    console.log("calling s3helper--->");
    this.read = function(params) {
        return new Promise((resolve, reject) => {
            s3.getObject(params, function(err, data) {
                if (err) {
                    console.log("S3 Read Fail!");
                    console.log(err, err.stack);
                    reject(err);
                } else {
                    console.log("S3 Read Successful!");
                    var result = Buffer.from(data.Body).toString('utf8');
                    console.log(JSON.parse(result));
                    return resolve(JSON.parse(result));
                }
            });
        });
    };
    this.reads = function(params) {
        console.log("calling s3helper--->");
        return new Promise((resolve, reject) => {
            s3.getObject(params, function(err, data) {
                if (err) {
                    console.log("S3 Read Fail!");
                    console.log(err, err.stack);
                    reject(err);
                } else {
                    console.log("S3 Read Successful!");
                    var result = Buffer.from(data.Body).toString('utf8');
                    console.log(result);
                    return resolve((result));
                }
            });
        });
    };
    this.write = function(params, result) {
        console.log("write method called---->");
        return new Promise((resolve, reject) => {
         console.log("promise method called---->");    
            var request = Object.assign({}, params);
            request.Body = Buffer.from(JSON.stringify(result), 'utf8');
            s3.putObject(request, function(err, data) {
                 console.log("s3 putObject called---->");
                if (err) {
                    console.log("S3 Upload Fail!");
                    console.log(err, err.stack);
                    reject(err);
                } else {
                    console.log("S3 Upload Successful!");
                    console.log(data);
                    return resolve(data);
                }
            });
        });
    };

    return this;
}