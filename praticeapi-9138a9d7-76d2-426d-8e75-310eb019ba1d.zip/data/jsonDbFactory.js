module.exports = function(BucketKey, tableName) {
    console.log("calling jsonDbFactory");
    return new require('./s3JsonDb')(BucketKey, tableName);
};