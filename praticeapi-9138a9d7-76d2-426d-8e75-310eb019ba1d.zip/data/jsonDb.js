const _ = require('lodash');

module.exports = function() {
    console.log("calling jsonDb");
    this.tableName = '';
    this.dbInstance = {};

    this.scanSync = function(filter, includedProperties = []) {
        var result = this.dbInstance.get(this.tableName);
        result = _.filter(result, filter);
        if (includedProperties.length > 0)
            result = _.map(result, _.partialRight(_.pick, includedProperties));
        return result;
    };

    this.findSync = function(filter, includedProperties = []) {
        var result = this.dbInstance.get(this.tableName);
        result = _.find(result, filter);
        if (includedProperties.length > 0)
            result = _.pick(result, includedProperties);
        return result;
    };

    this.addSync = function(item) {
        var result = this.dbInstance.get(this.tableName);
        result.push(item);
        this.dbInstance.set(this.tableName, result);
    }

    this.updateSync = function(filter, newItem) {
        var result = this.dbInstance.get(this.tableName);
        var index = _.findIndex(result, filter);
        var item = _.find(result, filter);
        _.merge(item, newItem);
        result.splice(index, 1, item);
        this.dbInstance.set(this.tableName, result);
    }

    this.deleteSync = function(filter) {
        var result = this.dbInstance.get(this.tableName);
       result= _.remove(result,filter);
        this.dbInstance.set(this.tableName, result);
    }
    this.findSyncs = function(filter) {
        var result = this.dbInstance.get(this.tableName);
        console.log("result findSyncs");
        console.log(result);
        result = _.find(result, filter);
       console.log(result);
        return result;
    };
    return this;
};