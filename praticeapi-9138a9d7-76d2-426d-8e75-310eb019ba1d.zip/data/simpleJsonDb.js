const { join } = require('path');
const simpleJsonDb = require('simple-json-db');

module.exports = function(databaseFileName, tableName) {
    console.log("calling simpleJsonDb");
    try {
        this.databaseFileName = databaseFileName;
        this.jsonDb = new require('./jsonDb');
        this.jsonDb.tableName = tableName;
        const file = join(__dirname, this.databaseFileName + ".json");
        this.jsonDb.dbInstance = new simpleJsonDb(file);
    } catch (error) {
        console.log(error);
    }

    this.scan = function(filter, includedProperties = []) {
        return new Promise((resolve, reject) => {
            try {
                return resolve(this.jsonDb.scanSync(filter, includedProperties));
            } catch (error) {
                if (err) reject(err);
            }
        });
    };

    this.find = function(filter, includedProperties = []) {
        return new Promise((resolve, reject) => {
            try {
                return resolve(this.jsonDb.findSync(filter, includedProperties));
            } catch (error) {
                if (err) reject(err);
            }
        });
    };

    this.add = function(item) {
        return new Promise((resolve, reject) => {
            try {
                return resolve(this.jsonDb.addSync(item));
            } catch (error) {
                if (err) reject(err);
            }
        });
    }

    this.update = function(filter, newItem) {
        return new Promise((resolve, reject) => {
            try {
                return resolve(this.jsonDb.updateSync(filter, newItem));
            } catch (error) {
                if (err) reject(err);
            }
        });
    }

    this.delete = function(filter) {
        return new Promise((resolve, reject) => {
            try {
                return resolve(this.jsonDb.deleteSync(filter));
            } catch (error) {
                if (err) reject(err);
            }
        });
    }

    return this;
};