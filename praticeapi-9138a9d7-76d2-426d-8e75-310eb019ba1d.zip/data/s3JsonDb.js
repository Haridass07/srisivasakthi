module.exports = function(BucketKey, tableName, BucketName = 'ionsstub') {
    console.log("calling s3JsonDb");
    this.jsonDb = new require('./jsonDb')();
    this.jsonDb.tableName = tableName;
    this.jsonDb.dbInstance = this;
    if(BucketKey.startsWith("XML"))
    {
        this.params = {
            Bucket: BucketName,
            Key: BucketKey + ".xml"
        };
    }
   else
   {
    this.params = {
        Bucket: BucketName,
        Key: BucketKey + ".json"
    };
   }
    this.result = {};
    this.s3Helper = new require('./s3helper')();

    this.get = function(tableName) {
        return this.result[tableName];
    }

    this.set = function(tableName, item) {
        this.result[tableName] = item;
    }

    this.scan = async function(filter, includedProperties = []) {
        this.result = await this.s3Helper.read(this.params);
        return this.jsonDb.scanSync(filter, includedProperties);
    };

    this.find = async function(filter, includedProperties = []) {
        console.log("called find ");
        this.result = await this.s3Helper.read(this.params);
        return this.jsonDb.findSync(filter, includedProperties);
    };

    this.add = async function(item) {
        this.result = await this.s3Helper.read(this.params);
        this.jsonDb.addSync(item);
        return this.s3Helper.write(this.params, this.result);
    }

    this.update = async function(filter, newItem) {
        this.result = await this.s3Helper.read(this.params);
        this.jsonDb.updateSync(filter, newItem);
        return this.s3Helper.write(this.params, this.result);
    }

    this.delete = async function(filter) {
        this.result = await this.s3Helper.read(this.params);
        console.log("delete function read s3 helper result=>");
        this.jsonDb.deleteSync(filter);
        return this.s3Helper.write(this.params, this.result);
    }
    this.finddata = async function(filter) {
        this.result = await this.s3Helper.reads(this.params);
        console.log("finddata");
       console.log(filter);
        return this.result;
    };
    return this;
};