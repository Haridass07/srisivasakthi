// const lambdaLocal = require('lambda-local');
// const path = require('path');
// var jsonPayload = {};

// lambdaLocal.execute({
//     event: jsonPayload,
//     lambdaPath: path.join(__dirname, 'index.js'),
//     timeoutMs: 3000,
//     clientContext: JSON.stringify({ clientId: 'xxxx' })
// });
const api = require('./api/dispatch');
var event = {
    //"routeKey": "POST /auth",
   //"body": {"Contract_number": "C123456","ANI":"41236986"}

    "routeKey": "POST /noanimatch",
    "body": {"Contract_number": "C123456","DOB":"06-11-1996","SSN":"4123"}

    //"routeKey": "POST /contract",
    //"body": {"Contract_number": "C123456"}

    //"routeKey": "POST /partyid",
    //"body": {"partyID": "41236"}
};
let response = {
    body: {},
    statusCode: 200,
    headers: {
        "Content-Type": "application/xml",
        "Access-Control-Allow-Headers": "Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token",
        "Access-Control-Allow-Methods": "POST,OPTIONS",
        "Access-Control-Allow-Origin": "*"
    }
};
console.log(event);
api.handler(event, response).then((response) => {
    console.log("**************");
    console.log(response);
    console.log("**************");
});